int main()
{
  int m_Colour = 3;
  switch (m_Colour)
  {
  case 1:
    cout << "Red";
    break;
  case 2:
    cout << "Blue";
    break;
  case 3:
    cout << "Green";
    break;
  case 4:
    cout << "Yellow";
    break;
  default:
    cout << "Invalid";
  }
}