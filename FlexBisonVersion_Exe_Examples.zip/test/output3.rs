pub fn main() {
let age: i32 = 20;
if age < 18
{
println!("You are a minor");
println!("\n");
}

else if age < 60 
{
println!("You are an adult");
println!("\n");
}

else 
{
println!("You are a senior citizen");
println!("\n");
}
}
