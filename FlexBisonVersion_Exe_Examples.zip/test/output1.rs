pub fn main() {
let m_Colour: i32 = 3;
match m_Colour{
1=>{
println!("Red");
},

2=>{
println!("Blue");
},

3=>{
println!("Green");
},

4=>{
println!("Yellow");
},

_ =>{
println!("Invalid");
},
}
}
