int main()
{
    int age = 20;
    if (age < 18)
    {
        cout << "You are a minor" << endl;
    }

    else if (age < 60)
    {
        cout << "You are an adult" << endl;
    }

    else
    {
        cout << "You are a senior citizen" << endl;
    }
}